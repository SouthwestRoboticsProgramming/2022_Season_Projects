#!/bin/bash

echo "Hello this is bash"

echo "line 2"
echo "line 3"
echo "line 4"

sleep 1

echo "fhaserawieyrrnx"

count=0

while :
do
  echo Count is $count
  count=$((count+1))
  sleep 1
done

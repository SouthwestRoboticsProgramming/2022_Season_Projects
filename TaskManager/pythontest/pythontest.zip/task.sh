#!/bin/bash

python2 clienttest.py
